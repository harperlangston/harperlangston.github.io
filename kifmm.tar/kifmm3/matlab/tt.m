numsrc = 10000;
numtrg = 20000;

srcpos = 2 * rand(3,numsrc) - 1;
srcnor = 2 * rand(3,numsrc) - 1;
trgpos = 2 * rand(3,numtrg) - 1;
ctr = [0;0;0];
rootlvl = 0;

%knl = cell(2,1); knl{1} = 111; knl{2} = ones(1,1);
%sdof = 1;
%np = 4;

knl = cell(2,1); knl{1} = 321; knl{2} = ones(1,1);
sdof = 3;
np = 6;

srcden = rand(sdof*numsrc, 1);

wis = cell(1,0);
tic; [trgval,wis] = fmm3d(srcpos, srcnor, trgpos, ctr, rootlvl, knl, np, srcden, wis); toc;
tic; [trgval,wis] = fmm3d(srcpos, srcnor, trgpos, ctr, rootlvl, knl, np, srcden, wis); toc;


