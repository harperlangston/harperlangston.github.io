function [trgval,wis] = fmm3d(srcpos, srcnor, trgpos, ctr, rootlvl, knl, np, srcden, wis)
%fmm3d: call the mex file 
  [trgval,wis] = fmm3d_mex(srcpos, srcnor, trgpos, ctr, rootlvl, knl, np, srcden, wis);
  
  
